#!/usr/bin/env python3
"""
CRITICAL CLEANUP - Deep cleaning of the codebase after refactoring
This script performs a thorough cleanup removing all redundant, obsolete, and unnecessary files
"""

import os
import shutil
from pathlib import Path
import subprocess

BASE_DIR = Path("/Users/plessas/SourceCode/etorotrade")

class CriticalCleanup:
    def __init__(self):
        self.removed_count = 0
        self.issues_found = []
        
    def log(self, msg, level="INFO"):
        prefix = {"INFO": "ℹ️", "WARN": "⚠️", "ERROR": "❌", "SUCCESS": "✅"}.get(level, "•")
        print(f"{prefix} {msg}")
        
    def remove_path(self, path: Path, description: str):
        """Safely remove a file or directory"""
        if path.exists():
            try:
                if path.is_dir():
                    shutil.rmtree(path)
                else:
                    path.unlink()
                self.log(f"Removed {description}: {path.name}", "SUCCESS")
                self.removed_count += 1
                return True
            except Exception as e:
                self.log(f"Failed to remove {path}: {e}", "ERROR")
        return False
    
    def clean_python_cache(self):
        """Remove all __pycache__ directories and .pyc files"""
        self.log("Cleaning Python cache files...", "INFO")
        count = 0
        
        # Remove all __pycache__ directories
        for pycache in BASE_DIR.rglob("__pycache__"):
            if self.remove_path(pycache, "cache directory"):
                count += 1
        
        # Remove all .pyc files
        for pyc in BASE_DIR.rglob("*.pyc"):
            if self.remove_path(pyc, "compiled file"):
                count += 1
                
        self.log(f"Removed {count} Python cache items", "SUCCESS")
    
    def remove_redundant_docs(self):
        """Remove unnecessary documentation files"""
        self.log("Removing redundant documentation...", "INFO")
        
        docs_to_remove = [
            # Obsolete refactoring docs
            BASE_DIR / "IMPROVEMENT_PLAN.md",
            BASE_DIR / "REFACTORING_COMPLETE_ITEMS_1-6.md", 
            BASE_DIR / "NEXT_IMPROVEMENTS.md",
            
            # Field-level docs that are too specific
            BASE_DIR / "docs/field_level_caching.md",
            BASE_DIR / "docs/CONFIG_UNIFICATION_COMPLETE.md",
            BASE_DIR / "docs/ticker-normalization.md",
            
            # Empty or unnecessary READMEs in test directories
            BASE_DIR / "tests/README.md",
            BASE_DIR / "tests/fixtures/README.md",
            BASE_DIR / "tests/integration/README.md",
            BASE_DIR / "tests/trade_modules/README_COMPREHENSIVE_TESTS.md",
            BASE_DIR / "tests/yahoofinance/core/README.md",
            BASE_DIR / "tests/yahoofinance/utils/network/README.md",
            
            # Other unnecessary docs
            BASE_DIR / "scripts/README.md",
            BASE_DIR / "tools/README.md",
            BASE_DIR / "yahoofinance/utils/DEPENDENCY_INJECTION.md",
        ]
        
        for doc in docs_to_remove:
            self.remove_path(doc, "documentation")
    
    def clean_duplicate_modules(self):
        """Remove duplicate module structures"""
        self.log("Analyzing module duplication...", "INFO")
        
        # Check if etorotrade and trade_modules have duplicate functionality
        etorotrade_dir = BASE_DIR / "etorotrade"
        trade_modules_dir = BASE_DIR / "trade_modules"
        
        if etorotrade_dir.exists() and trade_modules_dir.exists():
            # trade_modules should be the main one since that's what the code imports
            # etorotrade was our attempt to migrate but it's not fully used
            self.log("Found both etorotrade/ and trade_modules/ - keeping trade_modules", "WARN")
            # Don't remove etorotrade yet - need to verify imports first
            self.issues_found.append("Duplicate module structure: etorotrade/ and trade_modules/")
    
    def remove_empty_directories(self):
        """Remove empty directories"""
        self.log("Removing empty directories...", "INFO")
        
        # Find and remove empty dirs (bottom-up to handle nested empty dirs)
        empty_dirs = []
        for dirpath, dirnames, filenames in os.walk(BASE_DIR, topdown=False):
            dir_path = Path(dirpath)
            # Skip .git and virtual env directories
            if '.git' in dir_path.parts or 'venv' in dir_path.parts or 'myenv' in dir_path.parts:
                continue
            
            # Check if directory is empty (no files, or only __pycache__)
            if not filenames and (not dirnames or dirnames == ['__pycache__']):
                empty_dirs.append(dir_path)
        
        for empty_dir in empty_dirs:
            self.remove_path(empty_dir, "empty directory")
    
    def clean_test_structure(self):
        """Clean up test files - remove empty or stub tests"""
        self.log("Cleaning test structure...", "INFO")
        
        tests_dir = BASE_DIR / "tests"
        if not tests_dir.exists():
            return
        
        # Find very small test files (likely stubs)
        for test_file in tests_dir.rglob("test_*.py"):
            if test_file.stat().st_size < 200:  # Less than 200 bytes is likely just imports
                with open(test_file) as f:
                    content = f.read()
                    # Check if it has actual test functions
                    if 'def test_' not in content or content.count('def test_') <= 1:
                        self.remove_path(test_file, "stub test file")
    
    def remove_obsolete_files(self):
        """Remove specific obsolete files"""
        self.log("Removing obsolete files...", "INFO")
        
        obsolete_files = [
            # Archived backups (we have git for history)
            BASE_DIR / "archived_backups",
            
            # Old example/template files
            BASE_DIR / "examples",
            
            # Unused tools
            BASE_DIR / "tools/optimizer.py",
            BASE_DIR / "tools/test_optimize.py",
            
            # Config files that might be deprecated
            BASE_DIR / ".pytest_cache",
            
            # Deprecated provider files
            BASE_DIR / "yahoofinance/api/providers/yahoo_finance_base.py",
        ]
        
        for file in obsolete_files:
            if file.exists():
                self.remove_path(file, "obsolete file/dir")
    
    def check_imports(self):
        """Verify imports are consistent"""
        self.log("Checking import consistency...", "INFO")
        
        # Check if etorotrade imports are used
        result = subprocess.run(
            ["grep", "-r", "from etorotrade", str(BASE_DIR), "--include=*.py"],
            capture_output=True, text=True
        )
        
        etorotrade_imports = len(result.stdout.strip().split('\n')) if result.stdout.strip() else 0
        
        # Check trade_modules imports
        result = subprocess.run(
            ["grep", "-r", "from trade_modules", str(BASE_DIR), "--include=*.py"],
            capture_output=True, text=True
        )
        
        trade_modules_imports = len(result.stdout.strip().split('\n')) if result.stdout.strip() else 0
        
        self.log(f"Found {etorotrade_imports} etorotrade imports", "INFO")
        self.log(f"Found {trade_modules_imports} trade_modules imports", "INFO")
        
        if etorotrade_imports > 0 and trade_modules_imports > 0:
            self.issues_found.append(f"Mixed imports: {etorotrade_imports} etorotrade, {trade_modules_imports} trade_modules")
    
    def consolidate_config_files(self):
        """Ensure only necessary config files remain"""
        self.log("Checking configuration files...", "INFO")
        
        # We should only have config.yaml as the main config
        config_files = list(BASE_DIR.glob("*.yaml")) + list(BASE_DIR.glob("*.yml"))
        config_files += list(BASE_DIR.glob("*.json"))
        
        essential_configs = ["config.yaml", "sonar-project.properties", ".gitignore", "requirements.txt"]
        
        for config in config_files:
            if config.name not in essential_configs:
                self.log(f"Found potentially unnecessary config: {config.name}", "WARN")
                self.issues_found.append(f"Unnecessary config file: {config.name}")
    
    def fix_directory_structure(self):
        """Fix the module structure issue"""
        self.log("Fixing directory structure...", "INFO")
        
        # Remove the unused etorotrade directory structure
        etorotrade_dir = BASE_DIR / "etorotrade"
        
        # First check if it's actually being used
        result = subprocess.run(
            ["grep", "-r", "from etorotrade", str(BASE_DIR), "--include=*.py", "--exclude-dir=etorotrade"],
            capture_output=True, text=True
        )
        
        if result.stdout.strip():
            # It's being used, we need to update imports
            self.log("etorotrade is being imported, keeping it", "WARN")
            self.issues_found.append("etorotrade directory is in use - manual intervention needed")
        else:
            # Not being used externally, safe to remove
            if etorotrade_dir.exists():
                self.remove_path(etorotrade_dir, "unused etorotrade directory")
    
    def remove_deprecated_config_files(self):
        """Remove deprecated configuration files from yahoofinance/core/config/"""
        self.log("Removing deprecated config files...", "INFO")
        
        config_dir = BASE_DIR / "yahoofinance/core/config"
        if config_dir.exists():
            deprecated_files = list(config_dir.glob("*.deprecated"))
            for file in deprecated_files:
                self.remove_path(file, "deprecated config file")
    
    def final_cleanup(self):
        """Final cleanup pass"""
        self.log("Performing final cleanup...", "INFO")
        
        # Remove any .DS_Store files (Mac)
        for ds_store in BASE_DIR.rglob(".DS_Store"):
            self.remove_path(ds_store, "OS file")
        
        # Remove backup directories from our refactoring
        for backup in BASE_DIR.glob("backup_*"):
            if backup.is_dir():
                self.remove_path(backup, "old backup directory")
    
    def run(self):
        """Execute the complete cleanup"""
        print("=" * 60)
        print("🔥 CRITICAL CLEANUP STARTING")
        print("=" * 60)
        
        # Create a safety backup first
        import time
        backup_name = f"safety_backup_{int(time.time())}.tar.gz"
        self.log(f"Creating safety backup: {backup_name}", "INFO")
        subprocess.run([
            "tar", "-czf", backup_name,
            "--exclude=__pycache__", "--exclude=.git", "--exclude=*.pyc",
            "."
        ], cwd=BASE_DIR)
        
        # Run all cleanup operations
        self.clean_python_cache()
        self.remove_redundant_docs()
        self.remove_obsolete_files()
        self.remove_deprecated_config_files()
        self.clean_test_structure()
        self.check_imports()
        self.fix_directory_structure()
        self.consolidate_config_files()
        self.remove_empty_directories()
        self.final_cleanup()
        
        # Report results
        print("\n" + "=" * 60)
        print("📊 CLEANUP SUMMARY")
        print("=" * 60)
        print(f"✅ Items removed: {self.removed_count}")
        
        if self.issues_found:
            print(f"\n⚠️ Issues requiring attention ({len(self.issues_found)}):")
            for issue in self.issues_found:
                print(f"  • {issue}")
        else:
            print("\n✅ No issues found!")
        
        print(f"\n💾 Safety backup created: {backup_name}")
        print("   To restore: tar -xzf " + backup_name)
        
        return len(self.issues_found) == 0

if __name__ == "__main__":
    cleanup = CriticalCleanup()
    success = cleanup.run()