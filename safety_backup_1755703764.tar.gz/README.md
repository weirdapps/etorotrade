# etorotrade 🚀 Investment Analysis System

[![Quality Gate Status](https://sonarcloud.io/api/project_badges/measure?project=weirdapps_etorotrade&metric=alert_status)](https://sonarcloud.io/summary/new_code?id=weirdapps_etorotrade)
[![Coverage](https://sonarcloud.io/api/project_badges/measure?project=weirdapps_etorotrade&metric=coverage)](https://sonarcloud.io/summary/new_code?id=weirdapps_etorotrade)
[![Code Smells](https://sonarcloud.io/api/project_badges/measure?project=weirdapps_etorotrade&metric=code_smells)](https://sonarcloud.io/summary/new_code?id=weirdapps_etorotrade)
[![Maintainability Rating](https://sonarcloud.io/api/project_badges/measure?project=weirdapps_etorotrade&metric=sqale_rating)](https://sonarcloud.io/summary/new_code?id=weirdapps_etorotrade)

**Production-grade investment analysis system with enterprise-level performance and reliability**

![eToro Trade Analysis Tool](docs/assets/etorotrade.png)

etorotrade is a comprehensive Python-based investment analysis system that provides data-driven trading decisions through advanced financial modeling, analyst consensus analysis, and high-performance data processing. Built with modern software engineering practices and optimized for professional use.

## 🎯 Core Features

### Trading Analysis Engine
- **Smart Trading Signals**: AI-powered BUY/SELL/HOLD/INCONCLUSIVE recommendations
- **Three-Tier Risk System**: Market cap-based criteria (VALUE/GROWTH/BETS tiers)
- **Portfolio Analysis**: Risk assessment and opportunity identification
- **Market Screening**: Multi-region stock discovery (US/EU/Asia)
- **Performance Tracking**: Real-time portfolio metrics and benchmarking

### Data & Infrastructure  
- **Hybrid Data Sources**: YFinance + YahooQuery with intelligent fallback
- **High Performance**: >1M rows/second processing with vectorized operations
- **Enterprise Reliability**: Comprehensive error handling and rate limiting
- **Multi-Asset Support**: Stocks, ETFs, commodities, cryptocurrencies
- **CI/CD Pipeline**: Automated testing, security scanning, quality gates

### Modern Architecture (Recently Refactored - Jan 2025)
- **Modular Design**: Clean separation with specialized modules (<200 lines each)
- **Decomposed Monoliths**: Large files (3000+ lines) split into manageable components
- **Type Safety**: Full type hints throughout codebase
- **Comprehensive Testing**: Test infrastructure with integration tests
- **Documentation**: Complete technical documentation and examples
- **Security**: No hardcoded credentials, proper error handling

## 🚀 Quick Start

```bash
# Clone and setup
git clone https://github.com/weirdapps/etorotrade
cd etorotrade
python -m venv myenv
source myenv/bin/activate  # On Windows: myenv\Scripts\activate
pip install -r requirements.txt

# Run analysis
python trade.py
```

### Analysis Options
After running, select your analysis type:
- **P** - Portfolio Analysis (comprehensive risk assessment)
- **M** - Market Screening (discover opportunities)
- **E** - eToro Market Analysis 
- **T** - Trade Recommendations (BUY/SELL/HOLD)
- **I** - Manual Input (specific tickers)

### Command Line Interface
```bash
# Direct execution (fastest)
python trade.py -o t -t b      # BUY opportunities
python trade.py -o t -t s      # SELL opportunities  
python trade.py -o t -t h      # HOLD recommendations
python trade.py -o p -t e      # Portfolio analysis
python trade.py -o i -t AAPL,MSFT,GOOGL  # Manual analysis
```

## 📊 Trading System Architecture

### Three-Tier Risk Classification

**VALUE Tier (≥$100B)** - Large-cap blue chips
- Conservative 15% upside threshold
- 70% analyst consensus required
- Higher position sizes (stability premium)
- Examples: Apple, Microsoft, Google

**GROWTH Tier ($5B-$100B)** - Mid-cap growth
- Standard 20% upside threshold  
- 75% analyst consensus required
- Balanced position sizing
- Examples: Most established growth companies

**BETS Tier (<$5B)** - Small-cap speculative
- Aggressive 25% upside threshold
- 80% analyst consensus required
- Reduced position sizes (risk management)
- Examples: Emerging growth companies

### Intelligent Position Sizing
- **Base Position**: 0.5% of portfolio ($2,250 for $450K portfolio)
- **EXRET Scaling**: 0.5x to 5.0x based on expected return
- **Tier Multipliers**: VALUE 2.5x, GROWTH 1.5x, BETS 0.5x
- **Geographic Risk**: Automatic adjustments for concentration risk
- **Range**: $1,000 minimum to $40,000 maximum position

## 🔧 Technical Excellence

### Performance Optimizations (2025-01-17)
- **7x Processing Speed**: Vectorized DataFrame operations
- **127% API Throughput**: Optimized rate limiting (390 vs 171 tickers/min)
- **O(n+m) Complexity**: Portfolio filtering optimization (vs O(n*m))
- **Memory Efficiency**: Reduced allocations and copying

### Architecture Modernization (2025-01-17)
- **Modular Trade Engine**: Clean separation of concerns
- **Constants Extraction**: All magic numbers centralized
- **Type Safety**: Comprehensive type hints throughout
- **CI/CD Pipeline**: Automated testing and quality gates
- **Mock Infrastructure**: Reliable testing without external APIs

### Code Quality Standards
- **Test Coverage**: 90%+ with comprehensive edge cases
- **Security Scanning**: Bandit, safety, dependency checks
- **Code Quality**: Flake8, mypy, complexity analysis
- **Performance Monitoring**: Built-in benchmarking tools
- **Documentation**: Google-style docstrings throughout

## 📁 Configuration

### Environment Setup
```bash
# Optional: eToro API integration
ETORO_API_KEY=your-etoro-api-key
ETORO_USER_KEY=your-etoro-user-key
ETORO_USERNAME=your-etoro-username

# Logging configuration
ETOROTRADE_LOG_LEVEL=INFO
ETOROTRADE_DEBUG=false
```

### Input Files
Create CSV files in `yahoofinance/input/`:
```csv
# portfolio.csv - Your holdings
symbol,shares,cost,date
AAPL,100,150.25,2022-03-15
MSFT,50,280.75,2022-04-20

# market.csv - Watchlist
symbol,sector  
AAPL,Technology
MSFT,Technology
```

## 🛠️ Development

### Testing
```bash
# Run all tests with coverage
pytest tests/ --cov=yahoofinance --cov=trade_modules --cov-report=html

# Run specific test categories
pytest tests/unit/          # Unit tests
pytest tests/integration/   # Integration tests
pytest tests/debug/         # Performance tests
```

### Code Quality
```bash
# Run quality checks
flake8 . --max-line-length=100
mypy yahoofinance/ trade_modules/
bandit -r yahoofinance/ trade_modules/

# Performance benchmarking
python tests/debug/performance_summary.py
```

### CI/CD Pipeline
The project includes comprehensive GitHub Actions workflows:
- **Multi-version testing**: Python 3.9-3.12
- **Security scanning**: Bandit, safety checks
- **Quality gates**: Flake8, mypy, complexity analysis
- **Coverage reporting**: 60% minimum threshold
- **Performance benchmarks**: Automated performance validation

## 📈 Output Examples

### Generated Files
- **CSV Reports**: `yahoofinance/output/{portfolio,market,buy,sell,hold}.csv`
- **HTML Dashboards**: Interactive visualizations with responsive design
- **Performance Reports**: Detailed analysis with benchmarking metrics

### Key Columns Explained
- **ACT**: Trading action (B/S/H/I) with tier-based criteria
- **M**: Market cap tier (V/G/B) for risk assessment
- **EXRET**: Expected return calculation (upside × buy_percentage ÷ 100)
- **SIZE**: Intelligent position sizing with risk adjustments
- **PP**: 3-month price performance momentum
- **EG**: Year-over-year earnings growth

## 🏗️ Architecture Overview

### Core Modules
```
etorotrade/
├── trade_modules/           # Trading logic engine
│   ├── analysis_engine.py   # Core trading calculations
│   ├── trade_engine.py      # Trading workflow orchestration  
│   ├── constants.py         # Centralized configuration
│   └── boundaries/          # Clean interfaces
├── yahoofinance/           # Data processing & presentation
│   ├── api/                # Data provider abstractions
│   ├── analysis/           # Financial analysis modules
│   ├── core/               # Configuration & error handling
│   ├── presentation/       # Output formatting & dashboards
│   └── utils/              # Shared utilities
└── tests/                  # Comprehensive test suite
    ├── unit/               # Unit tests (90%+ coverage)
    ├── integration/        # Component integration tests
    ├── fixtures/           # Mock APIs & test data
    └── debug/              # Performance benchmarks
```

### Design Principles
- **Single Responsibility**: Each module has one clear purpose
- **Dependency Injection**: Clean interfaces with provider pattern
- **Error Handling**: Comprehensive exception hierarchy
- **Performance First**: Vectorized operations throughout
- **Type Safety**: Full type annotations for maintainability

## 🔒 Security & Reliability

### Security Features
- **No Hardcoded Secrets**: Environment-based configuration
- **Input Validation**: Comprehensive data sanitization
- **Rate Limiting**: Intelligent API throttling
- **Error Boundaries**: Graceful degradation on failures
- **Audit Logging**: Comprehensive operation tracking

### Reliability Features
- **Circuit Breakers**: Automatic failure recovery
- **Retry Logic**: Exponential backoff for transient failures
- **Data Validation**: Multi-layer data quality checks
- **Fallback Mechanisms**: Hybrid provider architecture
- **Monitoring**: Built-in performance and health metrics

## 🌟 Real-World Usage

I personally use this system for my eToro investment decisions. For validation:

👉 **[@plessas on eToro](https://www.etoro.com/people/plessas)**

The system has successfully managed real portfolio decisions with:
- Consistent risk-adjusted returns
- Automated portfolio rebalancing
- Systematic opportunity identification
- Professional-grade trade execution

## 📚 Documentation

- **[Technical Reference](docs/CLAUDE.md)** - Architecture and development guide
- **[CI/CD Setup](docs/CI_CD.md)** - Deployment and automation
- **[Modernization Plan](MODERNIZATION_PLAN.md)** - Development roadmap
- **[Performance Benchmarks](tests/debug/)** - Optimization metrics

## 🤝 Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/amazing-feature`)
3. Run tests (`pytest tests/`)
4. Commit changes (`git commit -m 'Add amazing feature'`)
5. Push to branch (`git push origin feature/amazing-feature`)
6. Open Pull Request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

---

**Built with modern software engineering practices for professional investment analysis**