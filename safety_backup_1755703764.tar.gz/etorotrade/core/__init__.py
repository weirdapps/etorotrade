"""
Core infrastructure module

This module provides a unified interface to core functionality
for the etorotrade package.
"""

# Import from local files (migrated from yahoofinance.core)
from .errors import (
    YFinanceError,
    ValidationError,
    APIError,
    NetworkError,
    DataError,
    ConfigError,
    CacheError,
    RateLimitError,
    ConnectionError,
    TimeoutError,
    ResourceNotFoundError,
    DataQualityError,
    MissingDataError,
    MonitoringError,
)

# Import from local files (migrated from yahoofinance.core)
from .logging import (
    get_logger,
    setup_logging,
    suppress_yfinance_noise,
)

# Import from local files (migrated from trade_modules)
from .config_manager import (
    get_config,
    ConfigManager,
    reload_config,
)

# Import from local files (migrated from trade_modules)
from .cache_service import (
    CacheService,
    get_cache,
    cached,
)

# Import from local files (migrated from yahoofinance.core.config)
from .config import (
    RATE_LIMIT,
    CIRCUIT_BREAKER,
    CACHE_CONFIG,
    FIELD_CACHE_CONFIG,
    PORTFOLIO_CONFIG,
    PROVIDER_CONFIG,
    TRADING_CRITERIA,
    DISPLAY,
    MESSAGES,
    PATHS,
    FILE_PATHS,
    COLUMN_NAMES,
    STANDARD_DISPLAY_COLUMNS,
    get_max_concurrent_requests,
    get_request_timeout,
    get_portfolio_value,
    get_input_dir,
    get_output_dir,
)

__all__ = [
    # Errors
    'YFinanceError',
    'ValidationError', 
    'APIError',
    'NetworkError',
    'DataError',
    'ConfigError',
    'CacheError',
    'RateLimitError',
    'ConnectionError',
    'TimeoutError',
    'ResourceNotFoundError',
    'DataQualityError',
    'MissingDataError',
    'MonitoringError',
    # Logging
    'get_logger',
    'setup_logging',
    'suppress_yfinance_noise',
    # Configuration
    'get_config',
    'ConfigManager',
    'reload_config',
    'RATE_LIMIT',
    'CIRCUIT_BREAKER',
    'CACHE_CONFIG',
    'FIELD_CACHE_CONFIG',
    'PORTFOLIO_CONFIG',
    'PROVIDER_CONFIG',
    'TRADING_CRITERIA',
    'DISPLAY',
    'MESSAGES',
    'PATHS',
    'FILE_PATHS',
    'COLUMN_NAMES',
    'STANDARD_DISPLAY_COLUMNS',
    'get_max_concurrent_requests',
    'get_request_timeout',
    'get_portfolio_value',
    'get_input_dir',
    'get_output_dir',
    # Cache
    'CacheService',
    'get_cache',
    'cached',
]