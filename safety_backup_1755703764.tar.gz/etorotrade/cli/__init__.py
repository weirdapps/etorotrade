"""
CLI module

This module provides a unified interface to command-line functionality
for the etorotrade package.
"""

# Import from local files (migrated from trade_modules)
from .trade_cli import (
    main,
    setup_secure_file_copy,
    config_validator,
)

from .cli import CLIManager as CLIHandler

__all__ = [
    'main',
    'setup_secure_file_copy',
    'config_validator',
    'CLIHandler',
]