"""
Utilities module - aggregates from existing locations

This module provides a unified interface to utility functions
currently spread across yahoofinance.utils and trade_modules.utils.
"""

# Re-export from yahoofinance.utils
from yahoofinance.utils.error_handling import (
    enrich_error_context,
    translate_error,
    with_retry,
    safe_operation,
)

from yahoofinance.utils.data.ticker_utils import (
    normalize_ticker,
    process_ticker_input,
    validate_ticker,
    clean_ticker_symbol,
)

from yahoofinance.utils.data.format_utils import (
    format_number,
    format_percentage,
    format_currency,
    calculate_position_size,
    calculate_validated_upside,
)

from yahoofinance.utils.data.asset_type_utils import (
    get_asset_type,
    is_etf,
    is_commodity,
    is_crypto,
    universal_sort_dataframe,
)

# Re-export from trade_modules.utils
from trade_modules.utils import (
    clean_ticker_symbol as clean_ticker,  # Avoid name collision
    normalize_ticker_for_display,
    normalize_ticker_list_for_processing,
)

__all__ = [
    # Error handling
    'enrich_error_context',
    'translate_error',
    'with_retry',
    'safe_operation',
    # Ticker utilities
    'normalize_ticker',
    'process_ticker_input',
    'validate_ticker',
    'clean_ticker_symbol',
    'clean_ticker',
    'normalize_ticker_for_display',
    'normalize_ticker_list_for_processing',
    # Formatting
    'format_number',
    'format_percentage',
    'format_currency',
    'calculate_position_size',
    'calculate_validated_upside',
    # Asset types
    'get_asset_type',
    'is_etf',
    'is_commodity',
    'is_crypto',
    'universal_sort_dataframe',
]