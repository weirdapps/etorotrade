"""
etorotrade - Unified trading analysis package

This package consolidates all trading functionality into a single, 
well-organized structure.
"""

__version__ = "2.0.0"
__author__ = "etorotrade"

# Maintain backward compatibility during migration
import sys
import os

# Add parent directory to path for compatibility
parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)

# Re-export commonly used items for convenience
try:
    from .core.errors import YFinanceError
    from .core.logging import get_logger
except ImportError:
    # During migration, these might not be available yet
    pass

__all__ = [
    'YFinanceError',
    'get_logger',
]