"""
Analysis module - aggregates from existing locations

This module provides a unified interface to analysis functionality
currently spread across yahoofinance.analysis and trade_modules.
"""

# Re-export from trade_modules
from trade_modules.analysis_engine import (
    AnalysisEngine,
    calculate_exret,
    calculate_action,
    calculate_action_vectorized,
)

from trade_modules.analysis_service import AnalysisService

# Re-export from yahoofinance.analysis
from yahoofinance.analysis.market import MarketAnalyzer
from yahoofinance.analysis.backtest import BacktestEngine
from yahoofinance.analysis.market_filters import (
    filter_opportunities,
    get_buy_opportunities,
    get_sell_opportunities,
    get_hold_opportunities,
)
from yahoofinance.analysis.performance import PerformanceTracker
from yahoofinance.analysis.optimize import OptimizerEngine

# Re-export criteria
from yahoofinance.core.trade_criteria_config import TradingCriteria

__all__ = [
    # Analysis engines
    'AnalysisEngine',
    'AnalysisService',
    'MarketAnalyzer',
    'BacktestEngine',
    'PerformanceTracker',
    'OptimizerEngine',
    # Functions
    'calculate_exret',
    'calculate_action',
    'calculate_action_vectorized',
    'filter_opportunities',
    'get_buy_opportunities',
    'get_sell_opportunities',
    'get_hold_opportunities',
    # Criteria
    'TradingCriteria',
]