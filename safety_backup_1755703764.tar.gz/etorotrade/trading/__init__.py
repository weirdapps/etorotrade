"""
Trading module - aggregates from existing locations

This module provides a unified interface to trading functionality
currently in trade_modules.
"""

# Lazy import to avoid circular dependencies
def get_trading_engine():
    from trade_modules.trade_engine import TradingEngine
    return TradingEngine

# For backward compatibility
TradingEngine = None

# Re-export portfolio management
from trade_modules.portfolio_service import PortfolioService

# Re-export data processing
from trade_modules.data_processor import DataProcessor
from trade_modules.data_processing_service import DataProcessingService

# Re-export filters
from trade_modules.filter_service import FilterService
from trade_modules.trade_filters import (
    filter_by_market_cap,
    filter_by_analyst_coverage,
    filter_by_price_targets,
)

# Re-export constants
from trade_modules.constants import (
    # Market cap thresholds
    MARKET_CAP_SMALL_THRESHOLD,
    MARKET_CAP_LARGE_THRESHOLD,
    TRILLION_MULTIPLIER,
    BILLION_MULTIPLIER,
    MILLION_MULTIPLIER,
    # Trading actions
    BUY_ACTION,
    SELL_ACTION,
    HOLD_ACTION,
    INCONCLUSIVE_ACTION,
    NO_ACTION,
    # Financial thresholds
    BETA_MIN,
    BETA_MAX,
    PE_MIN,
    PE_MAX,
    PEG_MIN,
    PEG_MAX,
    # Display
    MISSING_DATA_DISPLAY,
    PERCENTAGE_MULTIPLIER,
)

__all__ = [
    # Engines and services
    'TradingEngine',
    'PortfolioService',
    'DataProcessor',
    'DataProcessingService',
    'FilterService',
    # Functions
    'filter_by_market_cap',
    'filter_by_analyst_coverage',
    'filter_by_price_targets',
    # Constants
    'MARKET_CAP_SMALL_THRESHOLD',
    'MARKET_CAP_LARGE_THRESHOLD',
    'TRILLION_MULTIPLIER',
    'BILLION_MULTIPLIER',
    'MILLION_MULTIPLIER',
    'BUY_ACTION',
    'SELL_ACTION',
    'HOLD_ACTION',
    'INCONCLUSIVE_ACTION',
    'NO_ACTION',
    'BETA_MIN',
    'BETA_MAX',
    'PE_MIN',
    'PE_MAX',
    'PEG_MIN',
    'PEG_MAX',
    'MISSING_DATA_DISPLAY',
    'PERCENTAGE_MULTIPLIER',
]