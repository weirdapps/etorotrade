"""
Presentation module - aggregates from existing locations

This module provides a unified interface to presentation/display functionality
currently spread across yahoofinance.presentation and trade_modules.
"""

# Re-export from yahoofinance.presentation
from yahoofinance.presentation.console import MarketDisplay
from yahoofinance.presentation.html import HTMLGenerator
from yahoofinance.presentation.formatter import DataFormatter

# Re-export from trade_modules
from trade_modules.output_manager import OutputManager
from trade_modules.display_manager import DisplayManager
from trade_modules.trade_display import (
    display_and_save_results,
    format_for_display,
)

__all__ = [
    # Display classes
    'MarketDisplay',
    'HTMLGenerator',
    'DataFormatter',
    'OutputManager',
    'DisplayManager',
    # Functions
    'display_and_save_results',
    'format_for_display',
]