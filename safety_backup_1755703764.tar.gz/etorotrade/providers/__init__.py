"""
Data providers module - aggregates from existing locations

This module provides a unified interface to all data providers
currently in yahoofinance.api.providers.
"""

# Re-export provider implementations
from yahoofinance.api.providers.yahoo_finance_provider import YahooFinanceProvider
from yahoofinance.api.providers.yahooquery_provider import YahooQueryProvider
from yahoofinance.api.providers.hybrid_provider import HybridProvider
from yahoofinance.api.providers.async_yahoo_finance import AsyncYahooFinanceProvider
from yahoofinance.api.providers.async_yahooquery import AsyncYahooQueryProvider
from yahoofinance.api.providers.async_hybrid_provider import AsyncHybridProvider

# Re-export base classes
from yahoofinance.api.providers.base_provider import (
    FinanceDataProvider,
    AsyncFinanceDataProvider,
)

# Re-export factory function
from yahoofinance import get_provider

__all__ = [
    # Sync providers
    'YahooFinanceProvider',
    'YahooQueryProvider',
    'HybridProvider',
    # Async providers
    'AsyncYahooFinanceProvider',
    'AsyncYahooQueryProvider',
    'AsyncHybridProvider',
    # Base classes
    'FinanceDataProvider',
    'AsyncFinanceDataProvider',
    # Factory
    'get_provider',
]