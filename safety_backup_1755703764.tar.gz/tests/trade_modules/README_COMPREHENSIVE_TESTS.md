# TradingEngine Comprehensive Test Suite

## 🎯 PURPOSE

**CRITICAL**: These tests are designed to catch ANY behavioral changes during the TradingEngine refactoring process. The TradingEngine is currently a god object that needs to be split, and these tests ensure no regression occurs during the decomposition.

## 📊 WHAT'S BEING TESTED

### Core Behavior Validation
- ✅ Complete `analyze_market_opportunities()` workflow with all data scenarios
- ✅ All filtering methods (`_filter_buy/sell/hold_opportunities`) with edge cases
- ✅ Portfolio integration logic (`_apply_portfolio_filters`) thoroughly tested
- ✅ Async batch processing behavior (`process_ticker_batch`, `_process_batch`)
- ✅ Confidence score calculations with various input combinations
- ✅ Notrade filtering logic with ticker equivalence checking
- ✅ Trading signal calculation vs existing BS/ACT column handling
- ✅ PositionSizer calculations with risk adjustments
- ✅ Factory functions and error handling scenarios

### Integration & Real-World Scenarios
- ✅ End-to-end data flow using real CSV data patterns
- ✅ Portfolio filtering with column name variations
- ✅ International ticker format handling (e.g., `0700.HK`, `ASML.AS`)
- ✅ Data validation with mixed/missing data types
- ✅ Performance characteristics with large datasets
- ✅ Behavioral regression prevention

## 📁 TEST FILES

### `test_trade_engine_comprehensive.py`
**Primary unit tests covering all TradingEngine methods**

| Test Class | Coverage |
|------------|----------|
| `TestAnalyzeMarketOpportunities` | Core workflow with BS/ACT columns, portfolio/notrade filtering |
| `TestFilteringMethods` | Individual filtering methods with edge cases |
| `TestPortfolioFiltering` | Portfolio integration with ticker equivalence |
| `TestConfidenceScoreCalculation` | Confidence score algorithm with various inputs |
| `TestNotradeFiltering` | Notrade filtering with ticker equivalence |
| `TestTradingSignalCalculation` | Signal calculation when BS/ACT missing |
| `TestAsyncBatchProcessing` | Async batch processing methods |
| `TestPositionSizer` | Position sizing with risk/beta/market cap adjustments |
| `TestFactoryFunctions` | Factory function behavior |
| `TestIntegrationScenarios` | End-to-end workflows |

### `test_trade_engine_integration.py`
**Integration tests using real CSV data structures**

| Test Class | Coverage |
|------------|----------|
| `TestRealDataIntegration` | Real CSV data structure handling |
| `TestDataValidationIntegration` | Mixed data types and validation |
| `TestPerformanceIntegration` | Performance with realistic dataset sizes |

### `test_behavioral_validation.py`
**Behavioral validation using actual project CSV files**

| Test Class | Coverage |
|------------|----------|
| `TestBehavioralValidation` | Baseline behavior validation |
| `TestBehavioralRegression` | Specific regression prevention |

## 🚀 RUNNING THE TESTS

### Quick Run (Recommended)
```bash
cd /Users/plessas/SourceCode/etorotrade/tests/trade_modules
python test_runner.py
```

### Individual Test Files
```bash
# Comprehensive unit tests
pytest test_trade_engine_comprehensive.py -v

# Integration tests
pytest test_trade_engine_integration.py -v

# Behavioral validation
pytest test_behavioral_validation.py -v
```

### Specific Test Categories
```bash
# Test only filtering methods
pytest test_trade_engine_comprehensive.py::TestFilteringMethods -v

# Test only portfolio integration
pytest test_trade_engine_comprehensive.py::TestPortfolioFiltering -v

# Test only confidence calculation
pytest test_trade_engine_comprehensive.py::TestConfidenceScoreCalculation -v
```

## 🔍 VALIDATION CRITERIA

### Before Refactoring
1. **ALL TESTS MUST PASS** ✅
2. Test coverage validates all critical methods are tested
3. Behavioral baseline is established

### During Refactoring
1. Run tests after each significant change
2. Any test failure indicates behavioral regression
3. Fix regressions before proceeding

### After Refactoring
1. ALL TESTS MUST STILL PASS ✅
2. Same behavioral outcomes with new structure
3. Performance characteristics maintained

## 🎭 TEST SCENARIOS COVERED

### Data Input Scenarios
- ✅ Market data with existing `BS` column
- ✅ Market data with `ACT` column (gets converted to `BS`)
- ✅ Market data without signals (triggers calculation)
- ✅ Empty/invalid data handling
- ✅ Mixed data types and missing values
- ✅ International ticker formats
- ✅ Large datasets (1000+ stocks)

### Portfolio Integration Scenarios
- ✅ Portfolio with `TICKER` column
- ✅ Portfolio with `Ticker` column
- ✅ Portfolio with `symbol` column
- ✅ Portfolio with `BS` classifications
- ✅ Portfolio with international holdings
- ✅ Ticker equivalence matching (e.g., `AAPL` vs `AAPL.US`)
- ✅ Portfolio filtering exclusions for buy opportunities
- ✅ Portfolio inclusion for sell/hold opportunities

### Confidence Score Scenarios
- ✅ High analyst coverage boosts confidence
- ✅ Missing critical data reduces confidence
- ✅ Strong returns increase confidence
- ✅ All NaN values fallback to base confidence
- ✅ Error handling with default confidence

### Filtering Logic Scenarios
- ✅ Buy: `BS == 'B'` with no additional filters
- ✅ Sell: `BS == 'S'` with confidence > 0.6 requirement
- ✅ Hold: `BS == 'H'` with no additional filters
- ✅ Confidence score handling (NaN filled with 0.5)
- ✅ Empty results when criteria not met

### Async Processing Scenarios
- ✅ Batch processing with configurable batch sizes
- ✅ Error handling for individual ticker failures
- ✅ Progress tracking with tqdm
- ✅ Ticker normalization and display formatting
- ✅ Provider data extraction and mapping

## ⚠️ CRITICAL BEHAVIORS TO PRESERVE

### 1. Opportunity Classification Logic
```python
# Buy opportunities: BS == 'B', no confidence filter
buy_mask = df["BS"] == "B"

# Sell opportunities: BS == 'S' AND confidence > 0.6
sell_mask = df["BS"] == "S"
sell_mask &= df["confidence_score"].fillna(0.5) > 0.6

# Hold opportunities: BS == 'H', no additional filters
hold_mask = df["BS"] == "H"
```

### 2. Portfolio Filtering Logic
```python
# Buy: Exclude portfolio holdings using ticker equivalence
# Sell: Include only portfolio holdings with 'S' signal + market 'S' signals for portfolio
# Hold: Include only portfolio holdings with 'H' signal + market 'H' signals for portfolio
```

### 3. ACT Column Handling
```python
# If ACT exists and BS doesn't, rename ACT to BS
if "ACT" in df.columns and "BS" not in df.columns:
    df["BS"] = df["ACT"]
```

### 4. Confidence Score Calculation
```python
# Base: 0.6
# >= 5 analysts: +0.2
# >= 10 analysts: +0.1 additional
# >= 5 total_ratings: +0.1
# Strong returns: +small bonus
# Missing upside: -0.2
# Missing buy_percentage: -0.2
# Clipped to [0, 1]
```

## 🏆 SUCCESS CRITERIA

### Test Suite Success
- ✅ All tests pass (no failures, no errors)
- ✅ Test coverage validates all critical methods tested
- ✅ Performance tests complete within time limits
- ✅ Integration tests work with real CSV structures

### Refactoring Readiness
- ✅ Baseline behavior fully documented in tests
- ✅ Edge cases and error scenarios covered
- ✅ Regression detection mechanisms in place
- ✅ Safe to proceed with god object decomposition

## 🔧 MAINTENANCE

### Adding New Tests
1. Follow existing test naming conventions
2. Use appropriate fixtures for data setup
3. Mock external dependencies (provider, file I/O)
4. Test both success and error scenarios
5. Update this README with new coverage

### Test Data Management
- Use realistic data patterns from actual CSV files
- Create fixtures for reusable test data
- Mock provider responses for consistent testing
- Clean up temporary files in teardown

### Performance Monitoring
- Large dataset tests validate scalability
- Batch processing tests ensure async efficiency
- Monitor test execution time for regressions

---

**⚠️ IMPORTANT**: Do not proceed with TradingEngine refactoring until ALL tests in this suite pass consistently. These tests are your safety net during the god object decomposition process.