"""
Test package for trade_modules.

This package contains comprehensive tests for the modularized trading components
including analysis engine, output manager, data processor, and CLI modules.
"""