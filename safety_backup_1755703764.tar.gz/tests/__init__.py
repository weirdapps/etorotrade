"""Test package for the trade application."""
