"""Unit tests for yahoofinance.utils package."""
