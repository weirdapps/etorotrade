"""Unit tests for yahoofinance package."""
