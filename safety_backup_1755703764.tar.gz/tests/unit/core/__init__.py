"""Unit tests for core functionality."""
