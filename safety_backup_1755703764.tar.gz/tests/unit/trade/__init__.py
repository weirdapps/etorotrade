"""Unit tests for trade module."""
