"""Test package for market utilities."""
