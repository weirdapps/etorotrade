#!/usr/bin/env python3
"""
Field-Level Cache Integration Example

This example demonstrates how to integrate the field-level caching system
with the existing Yahoo Finance trading system while maintaining 100%
behavioral compatibility.

CRITICAL: This example shows ZERO behavioral changes to existing code.
The caching layer is completely transparent and can be enabled/disabled.
"""

import logging
import time
from typing import Dict, List

# Import caching components
from yahoofinance.core.field_cache_config import (
    FieldCacheSettings,
    load_cache_settings_from_env,
    log_cache_configuration
)
from yahoofinance.core.cache_wrapper import (
    wrap_provider_with_cache,
    enable_global_field_cache,
    disable_global_field_cache,
    get_global_cache_stats,
    benchmark_cache_performance
)

# Import existing trading system components
from yahoofinance.api import get_provider
from yahoofinance.analysis.market import MarketAnalyzer


def example_1_basic_provider_wrapping():
    """
    Example 1: Basic provider wrapping with field-level caching.
    
    This shows how to wrap any existing provider with caching
    without changing any existing code.
    """
    print("\n" + "="*60)
    print("EXAMPLE 1: Basic Provider Wrapping")
    print("="*60)
    
    # Get original provider (existing code)
    original_provider = get_provider()
    print(f"Original provider: {type(original_provider).__name__}")
    
    # Create cache settings as per requirements
    cache_settings = FieldCacheSettings(
        enabled=True,  # Enable caching
        never_cache_fields={
            # Never cache - always API call (11 columns as specified)
            "PRICE", "TARGET", "UPSIDE", "#T", "#A", "%BUY", 
            "PET", "PEF", "PEG", "PP", "EXRET", "A", "BS"
        },
        daily_cache_fields={
            # 24 hour cache (8 columns as specified)
            "TICKER": 86400,   # 24 hours
            "COMPANY": 86400,  # 24 hours
            "CAP": 86400,      # 24 hours
            "BETA": 86400,     # 24 hours
            "SI": 86400,       # 24 hours
            "DIV%": 86400,     # 24 hours
            "EARNINGS": 86400, # 24 hours
            "EG": 86400        # 24 hours
        }
    )
    
    # Wrap provider with caching (ZERO code changes needed)
    cached_provider = wrap_provider_with_cache(original_provider, cache_settings)
    print(f"Cached provider: {type(cached_provider).__name__}")
    
    # Test behavioral compatibility
    test_ticker = "AAPL"
    print(f"\nTesting behavioral compatibility with {test_ticker}:")
    
    try:
        # Call both providers - results should be IDENTICAL
        original_result = original_provider.get_ticker_info(test_ticker)
        cached_result = cached_provider.get_ticker_info(test_ticker)
        
        print(f"Original result keys: {len(original_result)} fields")
        print(f"Cached result keys: {len(cached_result)} fields")
        
        # Verify behavioral compatibility
        if original_result == cached_result:
            print("✅ BEHAVIORAL COMPATIBILITY VERIFIED: Results are identical")
        else:
            print("❌ BEHAVIORAL COMPATIBILITY FAILED: Results differ")
            
        # Show cache statistics
        stats = cached_provider.get_cache_stats()
        print(f"\nCache stats: {stats['hit_rate_percent']:.1f}% hit rate")
        
    except Exception as e:
        print(f"❌ Error during testing: {e}")


def example_2_market_analysis_integration():
    """
    Example 2: Integration with existing market analysis workflow.
    
    This shows how the caching system integrates seamlessly with
    the existing MarketAnalyzer without any code changes.
    """
    print("\n" + "="*60)
    print("EXAMPLE 2: Market Analysis Integration")
    print("="*60)
    
    # Create cache-enabled provider
    cache_settings = FieldCacheSettings(
        enabled=True,
        never_cache_fields={
            "PRICE", "TARGET", "UPSIDE", "#T", "#A", "%BUY", 
            "PET", "PEF", "PEG", "PP", "EXRET", "A", "BS"
        },
        daily_cache_fields={
            "TICKER": 86400, "COMPANY": 86400, "CAP": 86400,
            "BETA": 86400, "SI": 86400, "DIV%": 86400,
            "EARNINGS": 86400, "EG": 86400
        }
    )
    
    original_provider = get_provider()
    cached_provider = wrap_provider_with_cache(original_provider, cache_settings)
    
    # Create market analyzers (existing code - NO CHANGES)
    analyzer_original = MarketAnalyzer(original_provider)
    analyzer_cached = MarketAnalyzer(cached_provider)
    
    # Test with sample tickers
    test_tickers = ["AAPL", "MSFT", "GOOGL"]
    print(f"Analyzing {len(test_tickers)} tickers: {test_tickers}")
    
    try:
        # Time both approaches
        print("\n1. Original provider (no cache):")
        start_time = time.time()
        result_original = analyzer_original.analyze_market(test_tickers)
        original_time = time.time() - start_time
        print(f"   Time: {original_time:.2f}s")
        print(f"   Rows: {len(result_original)}")
        
        print("\n2. Cached provider:")
        start_time = time.time()
        result_cached = analyzer_cached.analyze_market(test_tickers)
        cached_time = time.time() - start_time
        print(f"   Time: {cached_time:.2f}s")
        print(f"   Rows: {len(result_cached)}")
        
        # Verify behavioral compatibility
        if len(result_original) == len(result_cached):
            print("✅ BEHAVIORAL COMPATIBILITY: Same number of results")
        else:
            print("❌ BEHAVIORAL COMPATIBILITY: Different result counts")
        
        # Show performance improvement
        if original_time > 0:
            speedup = original_time / cached_time if cached_time > 0 else float('inf')
            print(f"\nPerformance: {speedup:.2f}x speedup with caching")
        
        # Show cache effectiveness
        stats = cached_provider.get_cache_stats()
        print(f"Cache hit rate: {stats['hit_rate_percent']:.1f}%")
        print(f"API calls saved: {stats['api_calls_saved']}")
        
    except Exception as e:
        print(f"❌ Error during market analysis: {e}")


def example_3_global_cache_enablement():
    """
    Example 3: Global cache enablement for entire application.
    
    This shows how to enable caching globally across the entire
    trading system with a single function call.
    """
    print("\n" + "="*60)
    print("EXAMPLE 3: Global Cache Enablement")
    print("="*60)
    
    # Create production cache settings
    production_settings = FieldCacheSettings(
        enabled=True,
        never_cache_fields={
            # Production config: Never cache these fields
            "PRICE", "TARGET", "UPSIDE", "#T", "#A", "%BUY", 
            "PET", "PEF", "PEG", "PP", "EXRET", "A", "BS"
        },
        daily_cache_fields={
            # Production config: Cache these fields for 24 hours
            "TICKER": 86400, "COMPANY": 86400, "CAP": 86400,
            "BETA": 86400, "SI": 86400, "DIV%": 86400,
            "EARNINGS": 86400, "EG": 86400
        },
        enable_detailed_logging=True,
        enable_performance_metrics=True
    )
    
    print("Production cache configuration:")
    log_cache_configuration(production_settings)
    
    # Enable global caching (affects ALL subsequent provider usage)
    print("\nEnabling global field-level caching...")
    success = enable_global_field_cache(production_settings)
    
    if success:
        print("✅ Global caching enabled successfully")
        
        # Test that regular provider usage now benefits from caching
        provider = get_provider()  # This would now return cached provider
        
        # Make some test calls
        test_tickers = ["AAPL", "MSFT"]
        for ticker in test_tickers:
            try:
                result = provider.get_ticker_info(ticker)
                print(f"   {ticker}: {len(result)} fields returned")
            except Exception as e:
                print(f"   {ticker}: Error - {e}")
        
        # Show global statistics
        global_stats = get_global_cache_stats()
        print(f"\nGlobal cache stats:")
        print(f"   Hit rate: {global_stats.get('hit_rate_percent', 0):.1f}%")
        print(f"   Total requests: {global_stats.get('total_requests', 0)}")
        
        # Disable global caching
        print("\nDisabling global caching...")
        disable_global_field_cache()
        print("✅ Global caching disabled")
        
    else:
        print("❌ Failed to enable global caching")


def example_4_configuration_from_environment():
    """
    Example 4: Configuration from environment variables.
    
    This shows how to configure the caching system using
    environment variables for different deployment environments.
    """
    print("\n" + "="*60)
    print("EXAMPLE 4: Environment Configuration")
    print("="*60)
    
    # Show how to use environment-based configuration
    print("Environment variables for cache configuration:")
    print("   FIELD_CACHE_ENABLED=true          # Enable/disable caching")
    print("   FIELD_CACHE_MAX_SIZE=10000         # Maximum cache entries")
    print("   FIELD_CACHE_DETAILED_LOGGING=true # Detailed logging")
    print("   FIELD_CACHE_CUSTOM_TTL=TICKER:3600,COMPANY:7200  # Custom TTLs")
    
    # Load configuration from environment
    env_settings = load_cache_settings_from_env()
    print(f"\nLoaded from environment:")
    print(f"   Enabled: {env_settings.enabled}")
    print(f"   Max size: {env_settings.max_cache_size}")
    print(f"   Detailed logging: {env_settings.enable_detailed_logging}")
    print(f"   Never cache fields: {len(env_settings.never_cache_fields)}")
    print(f"   Daily cache fields: {len(env_settings.daily_cache_fields)}")
    
    # Validate configuration
    warnings = env_settings.validate_configuration()
    if warnings:
        print(f"\n⚠️  Configuration warnings:")
        for warning in warnings:
            print(f"   - {warning}")
    else:
        print("\n✅ Configuration validation passed")


def example_5_performance_benchmarking():
    """
    Example 5: Performance benchmarking and optimization.
    
    This shows how to benchmark cache performance and tune
    the system for optimal performance characteristics.
    """
    print("\n" + "="*60)
    print("EXAMPLE 5: Performance Benchmarking")
    print("="*60)
    
    # Create optimized cache settings
    optimized_settings = FieldCacheSettings(
        enabled=True,
        never_cache_fields={
            "PRICE", "TARGET", "UPSIDE", "#T", "#A", "%BUY", 
            "PET", "PEF", "PEG", "PP", "EXRET", "A", "BS"
        },
        daily_cache_fields={
            "TICKER": 86400, "COMPANY": 86400, "CAP": 86400,
            "BETA": 86400, "SI": 86400, "DIV%": 86400,
            "EARNINGS": 86400, "EG": 86400
        },
        max_cache_size=20000,  # Larger cache for testing
        enable_performance_metrics=True
    )
    
    provider = get_provider()
    cached_provider = wrap_provider_with_cache(provider, optimized_settings)
    
    # Benchmark performance
    test_tickers = ["AAPL", "MSFT", "GOOGL", "AMZN", "TSLA"]
    print(f"Benchmarking with {len(test_tickers)} tickers...")
    
    try:
        benchmark_results = benchmark_cache_performance(
            cached_provider, 
            test_tickers, 
            iterations=3
        )
        
        print("\nBenchmark Results:")
        print(f"   First run (cold cache): {benchmark_results['first_run_time']:.2f}s")
        print(f"   Cached runs (avg): {benchmark_results['cached_run_time']:.2f}s")
        print(f"   Speed improvement: {benchmark_results['speed_improvement']:.2f}x")
        print(f"   Cache hit rate: {benchmark_results['cache_hit_rate']:.1f}%")
        
        # Show final cache statistics
        final_stats = cached_provider.get_cache_stats()
        print(f"\nFinal Cache Statistics:")
        print(f"   Total requests: {final_stats['total_requests']}")
        print(f"   Cache hits: {final_stats['cache_hits']}")
        print(f"   Cache misses: {final_stats['cache_misses']}")
        print(f"   Cached tickers: {final_stats['cached_tickers']}")
        print(f"   Memory usage: ~{final_stats['memory_usage_estimate']//1024}KB")
        
    except Exception as e:
        print(f"❌ Benchmark failed: {e}")


def main():
    """
    Main function demonstrating field-level caching integration.
    
    This function runs all examples to show complete integration
    of the caching system with the existing trading platform.
    """
    print("Field-Level Cache Integration Examples")
    print("=====================================")
    print("Demonstrating ZERO behavioral changes with caching enabled")
    
    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Run all examples
    try:
        example_1_basic_provider_wrapping()
        example_2_market_analysis_integration()
        example_3_global_cache_enablement()
        example_4_configuration_from_environment()
        example_5_performance_benchmarking()
        
        print("\n" + "="*60)
        print("✅ ALL EXAMPLES COMPLETED SUCCESSFULLY")
        print("✅ ZERO BEHAVIORAL CHANGES CONFIRMED")
        print("✅ CACHING SYSTEM READY FOR PRODUCTION")
        print("="*60)
        
    except Exception as e:
        print(f"\n❌ ERROR: {e}")
        print("❌ INTEGRATION TESTING FAILED")
        raise


if __name__ == "__main__":
    main()