"""Performance reporting utilities"""
class PerformanceReporter:
    def generate_report(self, metrics):
        return {"summary": metrics}
