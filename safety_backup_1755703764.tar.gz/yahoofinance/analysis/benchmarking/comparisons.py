"""Benchmark comparison utilities"""
class BenchmarkComparator:
    def compare(self, portfolio, benchmark):
        return {"relative_performance": 0.0}
