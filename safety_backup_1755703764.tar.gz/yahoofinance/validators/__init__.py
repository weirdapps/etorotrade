"""
Validators for yahoo finance data.

This module provides validation utilities for working with yahoo finance data.
"""
